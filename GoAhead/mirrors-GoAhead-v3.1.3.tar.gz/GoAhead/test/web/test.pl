#!/usr/bin/perl

print "Content-type: text/html\n";
print "\n";
print "<html><head>\n";
print "</head>\n";
print "<body>\n";
print "<h1>Hello World from Perl</h1>\n";
print "</body>\n";
print "</html>\n";

0;
